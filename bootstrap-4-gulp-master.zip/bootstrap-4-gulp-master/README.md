# Starter Bootstrap 4 with Browser Sync SCSS Compiler and Font Awesome

### Usage:

#### npm install
#### bower install

#### gulp watch
#### gulp build
